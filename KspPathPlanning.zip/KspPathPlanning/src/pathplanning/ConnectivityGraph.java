/*
    Java app for testing the proposed path planning algorithm.
    JDK 1.7 or 1.8 is required.
 */

package pathplanning;

// -----------------------------------------------------------------------------
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// -----------------------------------------------------------------------------
class ConnectivityGraph {

    private final Map<String, ArrayList> nodes = new HashMap();
    private final Map<String, ArrayList> links = new HashMap();

    // -------------------------------------------------------------------------
    public boolean containsNode(String node) {
        return nodes.containsKey(node);                                 // O(1)
    }

    // -------------------------------------------------------------------------
    public ArrayList<String> getAdjacentNodes(String node) {
        return nodes.get(node);                                         // O(1)
    }

    // -------------------------------------------------------------------------
    public ArrayList<String> getAdjacentLinks(String node) {
        return links.get(node);                                         // O(1)
    }
    
    // -------------------------------------------------------------------------
    public void addNode(String node, ArrayList newAdjacentNodes) {
        if (!nodes.containsKey(node)) {                                 // O(1)
            nodes.put(node, newAdjacentNodes);                          // O(1)
        } else {
            nodes.get(node).addAll(newAdjacentNodes);                   // O(n)
        }
    }

    // -------------------------------------------------------------------------
    public void addLink(String node, ArrayList newAdjacentLinks) {
        if (!links.containsKey(node)) {                                 // O(1)
            links.put(node, newAdjacentLinks);                          // O(1)
        } else {
            links.get(node).addAll(newAdjacentLinks);                   // O(n)
        }
    }
    
    // -------------------------------------------------------------------------
    public void removeNode(String node) {
        nodes.remove(node);                                             // O(1)
        links.remove(node);                                             // O(1)
    }
    
    // -------------------------------------------------------------------------
    public void removeLink(String link) {

        int index;
        String adjacentNode = null;
        ArrayList<String> cnodes, clinks;

        for (String node : links.keySet()) {
            clinks = links.get(node);
            index = clinks.indexOf(link);
            if (index != -1) {
                cnodes = nodes.get(node);
                adjacentNode = cnodes.set(index, "blocked");
                break;
            }
        }
        if (adjacentNode != null) {
            clinks = links.get(adjacentNode);
            index = clinks.indexOf(link);
            if (index != -1) {
                cnodes = nodes.get(adjacentNode);
                cnodes.set(index, "blocked");
            }
        }   
    }
    
    // -------------------------------------------------------------------------
    public void insertTargetVirtualNode(String newnode, String target_nodes[]) {

        ArrayList nodeList = new ArrayList();
        ArrayList linkList = new ArrayList();
        Pattern p;
        Matcher m;
        boolean searchFlag;

        int n = target_nodes.length;
        for (int i = 0; i < n; i++) {
            String target_node = target_nodes[i];

            for (String node : nodes.keySet()) {
                if (target_node.startsWith("regex")) {        // Template search
                    String template = target_node.substring(5);
                    p = Pattern.compile(template);
                    m = p.matcher(node);
                    searchFlag = m.find();
                } else {
                    searchFlag = node.equals(target_node);  // Node name search 
                }
                if (searchFlag) {
                    ArrayList<String> adjacentNodes = nodes.get(node);  // O(1)
                    ArrayList<String> adjacentLinks = links.get(node);  // O(1)
                    adjacentNodes.add(newnode);                         // O(1)
                    adjacentLinks.add("vd");                            // O(1)
                    nodeList.addAll(adjacentNodes);                     // O(n)
                    linkList.addAll(adjacentLinks);                     // O(n)  
                }
            }
        }
        if (!nodeList.isEmpty()) {                      
            if (nodes.containsKey(newnode)) {                           // O(1)
                nodes.get(newnode).addAll(nodeList);                    // O(n)
                links.get(newnode).addAll(linkList);                    // O(n)
            }
            else {
                nodes.put(newnode, nodeList);                           // O(1)
                links.put(newnode, linkList);                           // O(1) 
            }
        }
    }

    // -------------------------------------------------------------------------
    public void insertStartVirtualNode(String node, String start_nodes[]) {

        ArrayList nodeList = new ArrayList();
        ArrayList linkList = new ArrayList();

        int n = start_nodes.length;
        for (int i = 0; i < n; i++) {
            String adjacent_node = start_nodes[i];
            nodeList.add(adjacent_node);                                // O(1)
            linkList.add("vd");                                         // O(1)
        }
        if (!nodeList.isEmpty()) {
            nodes.put(node, nodeList);                                  // O(1)
            links.put(node, linkList);                                  // O(1)            
        }
    }

    // -------------------------------------------------------------------------
    public void removeLink1(String link) {

        int index, counter = 0;
        ArrayList<String> cnodes, clinks;
        ArrayList<String> emptyNodes = new ArrayList();

        for (String node : nodes.keySet()) {
            clinks = links.get(node);
            index = clinks.indexOf(link);
            if (index != -1) {
                cnodes = nodes.get(node);
                clinks.remove(index);                                   // O(n)
                cnodes.remove(index);                                   // O(n)
                counter++;
            }
            if (clinks.isEmpty()) {
                emptyNodes.add(node);
            }
            if (counter == 2) {
                break;
            }
        }
        for (String node : emptyNodes) {
            nodes.remove(node);
            links.remove(node);
        }
    }

    // -------------------------------------------------------------------------
    public void showConnectivityInfo() {

        HashSet<String> allLinks = new HashSet();
        for (String node : links.keySet()) {
            List clinks = links.get(node);
            int nLinks = clinks.size();
            for (int i = 0; i < nLinks; i++) {
                allLinks.add((String) clinks.get(i));
            }
        }
        int numberOfLinks = allLinks.size();
        int numberOfNodes = nodes.size();
        // -----------------------------------------------------------------
        System.out.println("Number of nodes: " + numberOfNodes);
        System.out.println("Number of links: " + numberOfLinks);
        System.out.println("Nodes:\n" + nodes);
        System.out.println("Links:\n" + links);
    }
    // -------------------------------------------------------------------------
}
