/*
 Java app for testing the proposed path planning algorithm.
 JDK 1.7 or 1.8 is required.
 */

package pathplanning;
// -----------------------------------------------------------------------------

import java.util.ArrayList;
import java.util.LinkedList;

class PathPlanning {

    private int iterations;
    private double search_time, remove_time;
    private boolean SIMPLE_PATHS = true;

    private LinkedList<String> current_nodes, current_links;
    private LinkedList<String> clone_current_nodes, clone_current_links;
    private ArrayList<LinkedList> visited_nodes, visited_links;
    private LinkedList<Integer> paths_to_remove;

    // -------------------------------------------------------------------------

    public PathPlanning() {
        current_nodes = new LinkedList<>();
        current_links = new LinkedList<>();
        clone_current_nodes = new LinkedList<>();
        clone_current_links = new LinkedList<>();

        visited_nodes = new ArrayList();
        visited_links = new ArrayList();
        paths_to_remove = new LinkedList();
    }

    // -------------------------------------------------------------------------
    public void start(ConnectivityGraph graph,
            String start, String target, boolean simplePathFlag) {

        SIMPLE_PATHS = simplePathFlag;
        double t1 = System.nanoTime();
        calculatePaths(graph, start, target);
        double t2 = System.nanoTime();
        search_time = (t2 - t1) / 1000000; // ms
    }

    // -------------------------------------------------------------------------
    double getSearchTime() {
        return search_time;
    }

    double getRemoveTime() {
        return remove_time;
    }

    int getIterations() {
        return iterations;
    }

    // -------------------------------------------------------------------------
    public void calculatePaths(ConnectivityGraph graph,
            String start, String target) throws OutOfMemoryError {

        boolean targetFlag, loopFlag, removeFlage;
        String last_node, last_link, cnode, clink;
        ArrayList<String> next_nodes, next_links;
        int NUM_OF_ROUTES, POSSIBLE_NEW_PATHS;

        current_nodes.add(start);                                       // O(1) 
        visited_nodes.add(current_nodes);                               // O(1)
        visited_links.add(current_links);                               // O(1)
        // ---------------------------------------------------------------------  

        while ((NUM_OF_ROUTES = visited_nodes.size()) != 0) {           // O(1)
            
            for (int i = 0; i < NUM_OF_ROUTES; i++) {
                
                current_nodes = visited_nodes.get(i);                   // O(1)
                current_links = visited_links.get(i);                   // O(1)
                last_node = current_nodes.pollLast();                   // O(1)
                targetFlag = last_node.equals(target);                  // O(1) 
                loopFlag = current_nodes.contains(last_node);           // O(n)
                current_nodes.addLast(last_node);                       // O(1)

                removeFlage = false;
                if (targetFlag) {
                    removeFlage = true;
                    FeasiblePaths.nodes.add(current_nodes);             // O(1)
                    FeasiblePaths.links.add(current_links);             // O(1)
                    if (FeasiblePaths.nodes.size()
                            == PathPlanningImplementation.K) {          // O(1)
                        return;
                    }
                } else if (loopFlag) {
                    if (SIMPLE_PATHS) {
                        removeFlage = true;
                    } else {
                        int n = current_links.size() - 1;               // O(1) 
                        last_link = current_links.peekLast();           // O(1)
                        int id = current_links.indexOf(last_link);      // O(n)
                        if (id != -1 && id != n) {
                            removeFlage = true;
                        }
                    }
                }
                if (removeFlage) {
                    paths_to_remove.add(i);                             // O(1)
                    continue;
                }
                next_nodes = graph.getAdjacentNodes(last_node);
                next_links = graph.getAdjacentLinks(last_node);
                try {
                    POSSIBLE_NEW_PATHS = next_nodes.size();             // O(1)
                } catch (NullPointerException exception) {
                    paths_to_remove.add(i);                             // O(1)
                    POSSIBLE_NEW_PATHS = 0;
                    // on-the-fly pathfinding
                    // add hire a programming code that loads missing node!
                }    
                for (int j = 0; j < POSSIBLE_NEW_PATHS; j++) {
                    cnode = next_nodes.get(j);                          // O(1)
                    clink = next_links.get(j);                          // O(1)  
                    clone_current_nodes = current_nodes;
                    clone_current_links = current_links;
                    current_nodes
                            = new LinkedList(current_nodes);            // O(b)
                    current_links
                            = new LinkedList(current_links);            // O(b)  
                    clone_current_nodes.add(cnode);                     // O(1)
                    clone_current_links.add(clink);                     // O(1)
                    if (j > 0) {
                        visited_nodes.add(clone_current_nodes);         // O(1)
                        visited_links.add(clone_current_links);         // O(1)
                    }
                }
            }
            removeInfeasiblePaths();
            // -----------------------------------------------------------------           
            if (++iterations > PathPlanningImplementation.MAX_PATH_LENGTH) {
                return;
            }
            // -----------------------------------------------------------------

        }
    }

    // -------------------------------------------------------------------------
    private void removeInfeasiblePaths() {
        long t1 = System.nanoTime();
        LinkedList ntemp, ltemp;
        int N = paths_to_remove.size();                             // O(1)
        while (N-- > 0) {
            int id = paths_to_remove.pollLast();                    // O(1)
            int n = visited_nodes.size() - 1;                       // O(1)
            ntemp = visited_nodes.remove(n);                        // O(1)
            ltemp = visited_links.remove(n);                        // O(1)
            if (id != n) {
                visited_nodes.set(id, ntemp);                       // O(1) 
                visited_links.set(id, ltemp);                       // O(1) 
            }
        }
        long t2 = System.nanoTime();
        remove_time += ((double) t2 - (double) t1) / 1000000; // ms
    }

    // -------------------------------------------------------------------------
    public void showFeasiblePaths() {

        boolean virtualNodeFlag, virtualLinkFlag;
        int N = FeasiblePaths.nodes.size();
        for (int i = 0; i < N; i++) {
            System.out.print("Path " + (i + 1) + ": ");
            LinkedList<String> tmp_nodes = FeasiblePaths.nodes.get(i);  // O(1)
            LinkedList<String> tmp_links = FeasiblePaths.links.get(i);  // O(1)

            int M = tmp_links.size();
            while (M-- > 0) {
                String cnode = tmp_nodes.pollFirst();
                String clink = tmp_links.pollFirst();
                virtualNodeFlag = !cnode.contains("virtual");
                virtualLinkFlag = !clink.equals("vd");

                if (virtualNodeFlag) {
                    System.out.print(" | ");
                    System.out.print(cnode);
                }
                if (virtualLinkFlag) {
                    System.out.print(" | ");
                    System.out.print(clink);
                }
            }
            String last_node = tmp_nodes.pollFirst();
            String data = last_node.contains("virtual")
                    ? " |" : " | " + last_node + " |";
            System.out.println(data);

        }
    }
    // -------------------------------------------------------------------------
}
