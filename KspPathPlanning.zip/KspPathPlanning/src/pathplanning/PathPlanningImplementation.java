/*
    Java app for testing the proposed path planning algorithm.
    JDK 1.7 or 1.8 is required.
 */

package pathplanning;

import java.util.*;
import java.nio.file.*;
import java.io.IOException;
import java.nio.charset.Charset;

// -----------------------------------------------------------------------------
enum FieldType {

    NODES, LINKS, NODES_TO_REMOVE, LINKS_TO_REMOVE
}
// -----------------------------------------------------------------------------

public class PathPlanningImplementation {

    static ConnectivityGraph graph;
    static PathPlanning planner;

    static boolean SHOW_GRAPH = false;
    static boolean SHOW_PATHS = true;
    static boolean FIND_SIMPLE_PATHS = true;
    static boolean WRITE_RESULT_TO_FILE = false;

    static int K = Integer.MAX_VALUE;
    static int MAX_PATH_LENGTH = 100;

    static String startNodes[] = {};
    static String targetNodes[] = {};
    static String connectivityModels[] = {};
   
    // -------------------------------------------------------------------------
    public static void main(String[] args) {

        // ---------------------------------------------------------- Initialize
        if (!initialize()) {
            System.out.println("Can't initialize program!");
            return;
        } 
        // ---------------------------------------------- Start and target nodes      
        String start, target;
        // ---------------------------------------------------------------------
        graph = new ConnectivityGraph();
        planner = new PathPlanning();
        // -------------------------------------------- Build connectivity graph
        String path = "src//connectivity//";
        loadBuildingConnectivityInfo(path, connectivityModels);

        // --------------------------------------------------- Set start node(s)
        if (startNodes.length == 1) {
            start = startNodes[0];
        } else {
            start = "start_virtual_node";
            graph.insertStartVirtualNode(start, startNodes);
        }
        // -------------------------------------------------- Set target node(s)
        target = targetNodes[0];
        if (targetNodes.length != 1 || target.startsWith("regex(")) {
            target = "target_virtual_node";
            graph.insertTargetVirtualNode(target, targetNodes);
        }
        // ---------------------------------------------------------------------
        if (SHOW_GRAPH) {
            graph.showConnectivityInfo();
        }
        // ---------------------------------------------------------------------
        if (start.equals(target)) {
            System.out.println("You are located in target node!");
            return;
        }
        // --------------------------------------------------- Start pathfinding
        try {
            planner.start(graph, start, target, FIND_SIMPLE_PATHS);
        } catch (OutOfMemoryError error) {
            System.out.println("Out of memory!\n"
                    + "Reason: " + error + "\n"
                    + "Number of paths: " + FeasiblePaths.nodes.size());
        } finally {
            if (WRITE_RESULT_TO_FILE) {
                saveResult(planner.getSearchTime());
            }
        }
        System.out.println("\nComputational time: " + planner.getSearchTime() + "[ms]");
        System.out.println("Remove infeasible paths time: " + planner.getRemoveTime() + "[ms]");
        System.out.println("While iterations: " + planner.getIterations());

        // ------------------------------------------------- Show feasible paths
        int n = FeasiblePaths.nodes.size();                             // O(1)
        System.out.println("\nFeasible paths: " + n);
        if (SHOW_PATHS) {
            planner.showFeasiblePaths();
        }
        
        // ---------------------------------------------------------------------
    }

    // -------------------------------------------------------------------------
    private static void loadBuildingConnectivityInfo(String path, String... files) {
        int N = files.length;
        for (int i = 0; i < N; i++) {
            buildConnectivityGraph(path + files[i]);
        }
    }
    // -------------------------------------------------------------------------
    private static boolean initialize() {
        boolean status = true;
        String property, value, parser[]; 
        Path fpath = Paths.get("src//initialization//init.txt");
        Charset charset = Charset.forName("utf-8");
        
        try {
            List<String> lines = Files.readAllLines(fpath, charset);
            for (String line : lines) {
                if (line.trim().equals("") || line.startsWith("//")) {
                    continue;
                }
                parser = line.split(":");
                property = parser[0]; 
                value = parser[1];
                int slashPos = value.indexOf("//");
                if (slashPos != -1) {
                    value = value.substring(0, slashPos);
                }
                value = value.trim();
                switch (property) {
                    case "K":
                        K = Integer.parseInt(value);
                        break;
                    case "MAX_PATH_LENGTH":
                        MAX_PATH_LENGTH = Integer.parseInt(value);
                        break;
                    case "FIND_SIMPLE_PATHS":
                        FIND_SIMPLE_PATHS = Boolean.parseBoolean(value);
                        break;
                    case "SHOW_GRAPH":
                        SHOW_GRAPH = Boolean.parseBoolean(value);
                        break;
                    case "SHOW_PATHS":
                        SHOW_PATHS = Boolean.parseBoolean(value);
                        break;
                    case "WRITE_RESULT_TO_FILE":
                        WRITE_RESULT_TO_FILE = Boolean.parseBoolean(value);
                        break;
                    case "START_NODE":
                        startNodes = value.split("\\s+");
                        break;
                    case "TARGET_NODE":
                        targetNodes = value.split("\\s+");
                        break;
                    case "CONNECTIVITY_MODELS":
                        connectivityModels = value.split("\\s+");
                        break;
                    default:
                        break;
                }
            }
            if (startNodes.length == 0 || startNodes[0].equals("")  || 
                targetNodes.length == 0 || targetNodes[0].equals("") || 
                connectivityModels.length == 0 || connectivityModels[0].equals("")) {
                status = false;
            }
            
        } catch (IOException ex) {
            System.out.println("CAN'T READ CONFIGURATION FILE!");
            status = false;
        } catch (ArrayIndexOutOfBoundsException e) {    
            System.out.println("WRONG FILE FORMAT!");
            status = false;
        } 
        return status;
        
    }
    // -------------------------------------------------------------------------
    private static void buildConnectivityGraph(final String fileName) {

        FieldType element = null;
        Path fpath = Paths.get(fileName);
        Charset charset = Charset.forName("utf-8");
        ArrayList<String> temp = new ArrayList();
        System.out.println("File: " + fileName);
        // ---------------------------------------------------------------------
        double t1 = System.nanoTime();

        try {
            List<String> lines = Files.readAllLines(fpath, charset);
            for (String line : lines) {
                if (line.trim().equals("") || line.startsWith("//")) {
                    continue;
                }
                switch (line) {
                    case "NODES":
                        element = FieldType.NODES;
                        continue;
                    case "LINKS":
                        element = FieldType.LINKS;
                        continue;
                    case "NODES_TO_REMOVE":
                        element = FieldType.NODES_TO_REMOVE;
                        continue;
                    case "LINKS_TO_REMOVE":
                        element = FieldType.LINKS_TO_REMOVE;
                        continue;
                }
                switch (element) {
                    case NODES:
                        String[] cnodes = line.trim().split("\\s+");
                        String node = cnodes[0];
                        temp = new ArrayList();
                        for (int i = 1; i < cnodes.length; i++) {
                            temp.add(cnodes[i]);                         // O(1)
                        }
                        graph.addNode(node, temp);
                        break;
                    case LINKS:
                        String[] clinks = line.trim().split("\\s+");
                        String link = clinks[0];
                        temp = new ArrayList();
                        for (int i = 1; i < clinks.length; i++) {
                            temp.add(clinks[i]);                         // O(1)
                        }
                        graph.addLink(link, temp);
                        break;
                    case NODES_TO_REMOVE:
                        String[] nodesToRemove = line.trim().split("\\s+");
                        for (String id : nodesToRemove) {
                            graph.removeNode(id);
                        }
                        break;
                    case LINKS_TO_REMOVE:
                        String[] linksToRemove = line.trim().split("\\s+");
                        for (String id : linksToRemove) {
                            graph.removeLink(id);
                        }
                        break;
                    default:
                }              
            }    
            
            // ---------------------------------------------------------------------
            double t2 = System.nanoTime();
            double elapsed = (t2 - t1) / 1000000; // ms
            System.out.println("Graph build time: " + elapsed + " [ms]");
            // ---------------------------------------------------------------------
        
        } catch (IOException ioe) {
            System.out.println("CAN'T READ CONFIGURATION FILE!");
        } catch (NullPointerException nex) {    
            System.out.println("WRONG FILE FORMAT!");
        } 
        
    }

    // -------------------------------------------------------------------------
    private static void saveResult(double elapsedTime) {
  
        String fileName = "src//results//result.txt";
        Path fpath = Paths.get(fileName);
        Date date = new Date();
        String data = date + "\nNumber of paths: " + FeasiblePaths.nodes.size()
                + "\nComputational time: " + elapsedTime + " ms.";
        
        try {
            Files.write(fpath, data.getBytes());
        } catch (IOException e) {
            System.out.println("Can't write result to a file!");
        }
    }
    // -------------------------------------------------------------------------
}
