/*
    Java app for testing the proposed path planning algorithm.
    JDK 1.7 or 1.8 is required.
 */

package pathplanning;

import java.util.ArrayList;
import java.util.LinkedList;

// -----------------------------------------------------------------------------
class FeasiblePaths {

    static ArrayList<LinkedList> nodes = new ArrayList();
    static ArrayList<LinkedList> links = new ArrayList();

}
// -----------------------------------------------------------------------------
